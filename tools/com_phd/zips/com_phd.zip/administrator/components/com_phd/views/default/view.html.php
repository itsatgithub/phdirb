<?php
// no direct access
defined('_JEXEC') or die('Restricted access');

// Import Joomla! libraries
jimport( 'joomla.application.component.view');
class PhdViewDefault extends JView {
    function display($tpl = null) {
        parent::display($tpl);
    }
}
?>