<?php
defined('_JEXEC') or die('Restricted access');
JToolBarHelper::title(JText::_('ScientificPublications'), 'generic.png');
JToolBarHelper::preferences('com_scientificpublications');
?>
<!-- Deafult administrator message -->
This is the default administrator view of your component. To edit it please edit the file:<br />
/administrator/components/com_scientificpublications/views/default/tmpl/default.php