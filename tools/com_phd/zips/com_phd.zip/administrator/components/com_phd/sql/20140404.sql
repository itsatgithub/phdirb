ALTER TABLE jos_phd_applicants ADD directory VARCHAR(255);
