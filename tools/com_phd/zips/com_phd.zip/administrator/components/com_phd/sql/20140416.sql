ALTER TABLE jos_phd_degrees ADD ongoing TINYINT(4);
