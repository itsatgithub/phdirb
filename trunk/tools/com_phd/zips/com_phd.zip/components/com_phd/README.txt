WOI

1.- la eleccion de los programme a) la generacion de las listas, b) la tabla con el order, c) salvar las opciones con el order
2.- he cambiado en la bd la tabla de progra